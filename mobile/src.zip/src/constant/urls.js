import { API_SERVER } from './apis'

export const API_USER_REGISTER = API_SERVER + '/Register'

export const HOST_IMG = API_SERVER + '/'
