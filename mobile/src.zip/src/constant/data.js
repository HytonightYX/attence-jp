export const DATE_FORMAT  = 'YYYY/MM/DD'
export const MONTH_FORMAT = 'YYYY/MM'

export const navIconList = [{name:'打卡', url:'/', icon:'clock-circle'},{
                             name:'请假', url:'/leave', icon:'frown'       },{
                             name:'月报', url:'/month', icon:'calendar'    },{
                             name:'设置', url:'/conf', icon:'setting'     }]
