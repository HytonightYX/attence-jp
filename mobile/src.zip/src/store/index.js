import languageStore from './Language'
import userStore from './User'

export default {
	languageStore,
	userStore
}
